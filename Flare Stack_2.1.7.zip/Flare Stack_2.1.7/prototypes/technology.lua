table.insert(
  data.raw["technology"]["oil-processing"].effects,
  {type = "unlock-recipe",recipe = "flare-stack"})