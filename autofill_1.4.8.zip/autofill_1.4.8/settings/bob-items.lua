--
-- Disclaimer: mp warranty void if edited.
--



return {
  ["ammo-bullets"] = {
    "electric-bullet-magazine", "poison-bullet-magazine", "acid-bullet-magazine", "flame-bullet-magazine",
    "he-bullet-magazine", "ap-bullet-magazine", "bullet-magazine"
  },
  ["ammo-shells"] = {"scatter-cannon-shell"},
  ["ammo-rockets"] = {
    "bob-rocket", "bob-flame-rocket", "bob-poison-rocket", "bob-acid-rocket", 
    "bob-explosive-rocket", "bob-electric-rocket", "bob-piercing-rocket",
  },
}
