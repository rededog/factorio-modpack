--
-- Disclaimer: mp warranty void if edited.
--

return {
  ["ammo-bullets"] = {"uranium-rounds-magazine", "piercing-rounds-magazine", "firearm-magazine"},
  ["ammo-rockets"] = {"rocket", "explosive-rocket"},
  ["ammo-shells"] = {"explosive-uranium-cannon-shell", "uranium-cannon-shell", "explosive-cannon-shell", "cannon-shell",},
  ["ammo-shotgun"]	= {"shotgun-shell", "piercing-shotgun-shell"},
  ["ammo-flamethrower"] = {"flamethrower-ammo"},
  ["fuels-all"] = {}, -- fuel tables not filled here because lack of "game" in this scope.
  ["fuels-high"] = {}
}
