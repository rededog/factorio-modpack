data:extend(
{
  {
    type = "item",
    name = "advanced-processing-unit",
    icon = "__bobplates__/graphics/icons/advanced-processing-unit.png",
    icon_size = 32,
    flags = {"goes-to-main-inventory"},
    subgroup = "intermediate-product",
    order = "f[advanced-processing-unit]",
    stack_size = 200
  },
}
)


