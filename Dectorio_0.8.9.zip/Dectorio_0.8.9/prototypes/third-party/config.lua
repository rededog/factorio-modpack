-- third-party/config

-- Config changes for Alien Biomes
if settings.startup["alien-biomes-terrain-scale"] then
	DECT.CONFIG.BASE_WATER_TILES = {"water", "deepwater"}
end
