-- data-final-fixes

require("prototypes.style.gui")

require("prototypes.entity.signs-icons")

require("prototypes.signal.final-fixes")
