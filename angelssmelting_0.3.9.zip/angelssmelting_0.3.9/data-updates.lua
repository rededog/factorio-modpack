require("prototypes.smelting-override")
require("prototypes.smelting-generate")

-- EXECUTE OVERRIDES
angelsmods.functions.OV.execute()
	