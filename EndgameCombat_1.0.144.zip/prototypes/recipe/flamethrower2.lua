data:extend(
{
  {
    type = "recipe",
    name = "flamethrower-2",
    enabled = false,
    energy = 15,
    ingredients =
    {
      {"flamethrower", 2},
      {"steel-plate", 25},
      {"advanced-circuit", 10},
      {"processing-unit", 5}
    },
    result = "flamethrower-2"
  }
}
)
