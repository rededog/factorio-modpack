# EndgameCombat
Adds more powerful weaponry and defence designed for keeping on par with endgame or modded enemies.
-----------------
Primary Features:
Concussion Turrets - More powerful versions of the gun turrets
Plasma Turrets - More powerful versions of the laser turrets
Cannon Turrets - Long range, slow firing turrets that prioritize spitters
A more powerful tank with better armor and combat range
Incendiary sulfur-based ammunition, in light and heavy (U238) variants
More capsules for combat, including acid and radiation
More tank and rocket ammunition, both for mid and end game (including Napalm and Nuclear variants)
Long-range activity scanner
More and stronger wall varieties
A better flamethrower, with increased range and damage
Better armor equipment
Turret range upgrade research
Turret regeneration research
Logistic robot defenses research
Power pole defenses research
Adds crated ammo for giving ammo turrets longer time between reloads and a small DPS boost
Adds shockwave turrets, which can attack all enemies in range simultaneously
Orbital Bombardment technology and hardware, for automated destruction of biter nests, or manual airstrike capability
Adds shield domes to protect large areas given sufficient energy

Secondary Features:
Better train penetration through hordes of biters
Contains integration with the Laser Beam mod
Biters, worms, and spawners drop Alien Tissue, which has some uses in production in research