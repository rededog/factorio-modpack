data.raw.item["sulfur"].stack_size = 200
data.raw.item["solid-fuel"].stack_size = 200
data.raw.item["uranium-235"].stack_size = 200
data.raw.item["uranium-238"].stack_size = 200
data.raw.item["uranium-ore"].stack_size = 200
data.raw["rail-planner"]["rail"].stack_size = 1000
