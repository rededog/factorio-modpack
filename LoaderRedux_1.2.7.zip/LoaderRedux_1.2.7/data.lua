-- if mods["Loader-Rotation-Fix"] then error("Loader snapping is built into LoaderRedux, disable Loader Snapping (Loader-Rotation-Fix) to use LoaderRedux") end
require("prototypes.copyPrototype")
require("prototypes.item")
require("prototypes.recipe")
require("prototypes.entity")
require("prototypes.technology")
