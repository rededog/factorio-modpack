data:extend{
  {
    type = "bool-setting",
    name = "miniloader-snapping",
    setting_type = "runtime-global",
    default_value = true,
    order = "miniloader-snapping",
  },
}