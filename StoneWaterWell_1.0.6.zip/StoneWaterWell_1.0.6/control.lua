require "util"

script.on_event(defines.events.on_tick, function(event)
	if game.tick % 15 ~= 0 then return end
	--TickTanks(event)

	if global.iwaterwell ~= nil then 
		for k, iwaterwell in pairs(global.iwaterwell) do
			if iwaterwell.valid then 
				local amount = 0
				if iwaterwell.fluidbox[1] ~= nil then
					amount = iwaterwell.fluidbox[1].amount
				end

				iwaterwell.fluidbox[1] = {
					["name"] = "water",
					["amount"] = amount + 301,
					["temperature"] = 20
				}
			end
		end
	end
end)

script.on_event(defines.events.on_built_entity, function(event)
	if event.created_entity.name == "stone-waterwell" then
		if global.iwaterwell == nil then
			global.iwaterwell = {}
		end
		
		local iwaterwell = event.created_entity
		table.insert(global.iwaterwell, iwaterwell)
	end
end)

script.on_event(defines.events.on_robot_built_entity, function(event)
	if event.created_entity.name == "stone-waterwell" then
		if global.iwaterwell == nil then
			global.iwaterwell = {}
		end
		
		local iwaterwell = event.created_entity
		table.insert(global.iwaterwell, iwaterwell)
	end
end)

-- disabled
function TickTanks(event)
	if global.iwaterwell ~= nil then 
		for k, iwaterwell in pairs(global.iwaterwell) do
			game.players[1].print(game.tick .. " TickTank " .. k)			
			if iwaterwell.valid then 
				game.players[1].print(game.tick .. " TickTank valid " .. k)							
				local amount = 0
				if iwaterwell.fluidbox[1] ~= nil then
					amount = iwaterwell.fluidbox[1].amount
				
					iwaterwell.fluidbox[1] = {
						["type"] = "water",
						["amount"] = amount + 301,
						["temperature"] = 10
					}
				end
			end
		end
	end
end