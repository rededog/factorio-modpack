
--entity
require("prototypes.entity.resources")
require("prototypes.entity.particles")
require("prototypes.autoplace-controls")

--tile
require("prototypes.tile.noise-layers")


