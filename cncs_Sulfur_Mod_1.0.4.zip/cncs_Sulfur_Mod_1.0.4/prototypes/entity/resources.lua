local function cnc_sulfur_mod_autoplace_settings(name, coverage)
  local ret = {
    control = name,
    sharpness = 0.84,
    richness_multiplier = 1300,
    richness_multiplier_distance_bonus = 30,
    richness_base = 88,
    starting_area_amount = 600,
    coverage = coverage,
    peaks = {
      {
        noise_layer = name,
        noise_octaves_difference = -1.5,
        noise_persistence = 0.3,
      },
    }
  }
  for i, resource in ipairs({ "sulfur" }) do
    if resource ~= name then
      ret.starting_area_size = 600 * coverage
    end
  end
  return ret
end

local function cnc_sulfur_mod_resource(name, map_color, hardness, coverage)
  if hardness == nil then hardness = 0.9 end
  if coverage == nil then coverage = 0.02 end
  return {
    type = "resource",
    name = name,
    icon_size = 32,
    icon = "__cncs_Sulfur_Mod__/graphics/icons/" .. name .. ".png",
    flags = {"placeable-neutral"},
    order="a-b-a",
    minable =
    {
      hardness = hardness,
      mining_particle = name .. "-particle",
      mining_time = 1.25,
      result = name
    },
    collision_box = {{ -0.1, -0.1}, {0.1, 0.1}},
    selection_box = {{ -0.5, -0.5}, {0.5, 0.5}},
    autoplace = cnc_sulfur_mod_autoplace_settings(name, coverage),
    stage_counts = {5000, 3000, 1500, 800, 400, 100, 50, 10},
    stages =
    {
      sheet =
      {
        filename = "__cncs_Sulfur_Mod__/graphics/entity/" .. name .. "-ore/" .. name .. "-ore.png",
        priority = "extra-high",
        width = 64,
        height = 64,
        frame_count = 8,
        variation_count = 8,
        hr_version =
          {
          filename = "__cncs_Sulfur_Mod__/graphics/entity/" .. name .. "-ore/hr-" .. name .. "-ore.png",
          priority = "extra-high",
          width = 128,
          height = 128,
          frame_count = 8,
          variation_count = 8,
          scale = 0.5
          }
      }
    },
    map_color = map_color
  }
end

data:extend(
{
  cnc_sulfur_mod_resource("sulfur", {r=0.980, g=0.933, b=0.133}, 0.1, 0.012)
}
)
