data:extend(
{
  {
    type = "autoplace-control",
    name = "sulfur",
    category = "resource",
    richness = true,
    order = "g-s"
  },
}
)