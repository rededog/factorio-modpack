data:extend(
{
  {
    type = "noise-layer",
    name = "sulfur"
  },
}
)
