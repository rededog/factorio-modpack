local function tilebuilt(e)
  local placeitem = e.item.name
  local refundcount = 0
  for _,v in pairs(e.tiles) do
    if v.old_tile.items_to_place_this and v.old_tile.items_to_place_this[placeitem] then
      refundcount = refundcount + 1
    end
  end
  return {name = placeitem, count = refundcount}
end

script.on_event(defines.events.on_player_built_tile, function(e)
  local refund = tilebuilt(e)
  if refund.count > 0 and e.stack.valid then
    local holding = 0
    if e.stack.valid_for_read then
      holding = e.stack.count
    end
    local fill = math.min(e.item.stack_size - holding, refund.count)
    if fill > 0 then
      e.stack.transfer_stack({name = refund.name, count = fill})
      refund.count = refund.count - fill
    end
  end
  if refund.count > 0 then
    game.players[e.player_index].insert(refund)
  end
end)

script.on_event(defines.events.on_robot_built_tile, function(e)
  local refund = tilebuilt(e)
  if refund.count > 0 then
    e.robot.get_inventory(defines.inventory.robot_cargo).insert(refund)
  end
end)
