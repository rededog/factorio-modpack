if not landfillpainting then landfillpainting = {} end
if not landfillpainting.config then
  landfillpainting.config = {}

  -- Adjust landfill crafting cost when using base factorio landfill recipes
  landfillpainting.config.costStone = nil

  -- If Angels refining is detected, the extra landfills are added as
  -- washing-plant recipes. These use mud instead of stone.
  landfillpainting.config.costMud = nil

  -- The default setting of nil leaves the costs unchanged.
  -- Change the above nil values to an integer to adjust costs
end
