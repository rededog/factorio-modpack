-- update interval in ticks
-- default 60
dispatcher_update_interval = 60
