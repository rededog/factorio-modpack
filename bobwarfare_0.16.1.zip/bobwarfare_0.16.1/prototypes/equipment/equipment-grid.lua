data:extend(
{
  {
    type = "equipment-grid",
    name = "power-armor-equipment-grid-mk3",
    width = 12,
    height = 12,
    equipment_categories = {"armor"}
  },
  {
    type = "equipment-grid",
    name = "power-armor-equipment-grid-mk4",
    width = 14,
    height = 14,
    equipment_categories = {"armor"}
  },
  {
    type = "equipment-grid",
    name = "power-armor-equipment-grid-mk5",
    width = 16,
    height = 16,
    equipment_categories = {"armor"}
  },
}
)


