require("defines")

data:extend
{
	{
		-- Disable smoke
		type = "bool-setting",
		name = UPS_up_defines.names.settings.disable_smoke,
		setting_type = "startup",
		default_value = true,
		order = "a-a"
	},	
	
	{
		-- Disable corpses
		type = "bool-setting",
		name = UPS_up_defines.names.settings.disable_corpses,
		setting_type = "startup",
		default_value = true,
		order = "a-b"
	},
}