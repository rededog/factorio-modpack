require("defines")

-- Remove smoke
if settings.startup[UPS_up_defines.names.settings.disable_smoke].value then
	for _, type in pairs(data.raw) do
		for _, entity in pairs(type) do
			if entity.smoke then
				if not (entity.type == "explosion" or entity.type == "construction-robot" or entity.type == "flame-thrower-explosion") then
					entity.smoke = nil
				end
			end
			if entity.energy_source then
				if entity.energy_source.smoke then
					entity.energy_source.smoke = nil
				end
			end
			if entity.burner then
				if entity.burner.smoke then
					entity.burner.smoke = nil
				end
			end
			if entity.type == "locomotive" then
				if entity.stop_trigger then
					if entity.stop_trigger[3] then
						entity.stop_trigger = entity.stop_trigger[3]
					end
				end	
			end	
		end
	end
end

-- Remove copses
if settings.startup[UPS_up_defines.names.settings.disable_corpses].value then
	for _, type in pairs(data.raw) do
		for _, entity in pairs(type) do
			if entity.type=="corpse" then
				entity.time_before_removed = 1
			end
		end
	end
end