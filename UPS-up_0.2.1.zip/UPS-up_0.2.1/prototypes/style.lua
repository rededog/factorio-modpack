data.raw["gui-style"].default["UPS-up_gui-top-button"] =
{
    type = "button_style",
    parent = "button_style",
    width = 32,
    height = 32,
    top_padding = 0,
    right_padding = 0,
    bottom_padding = 0,
    left_padding = 0,
    default_graphical_set = {
      type = "monolith",
      monolith_image = {
        filename = "__UPS-up__/graphics/UPS-up_gui.png",
        priority = "extra-high-no-scale",
        width = 32,
        height = 32,
        x = 0
      }
    },
    hovered_graphical_set = {
      type = "monolith",
      monolith_image = {
        filename = "__UPS-up__/graphics/UPS-up_gui.png",
        priority = "extra-high-no-scale",
        width = 32,
        height = 32,
        x = 32
      }
    },
    clicked_graphical_set = {
      type = "monolith",
      monolith_image = {
        filename = "__UPS-up__/graphics/UPS-up_gui.png",
        priority = "extra-high-no-scale",
        width = 32,
        height = 32,
        x = 64
      }
    },
}

data.raw["gui-style"].default["UPS-up_options-button"] =
{
    type = "button_style",
    parent = "button_style",
    width = 16,
    height = 16,
    top_padding = 0,
    right_padding = 0,
    bottom_padding = 0,
    left_padding = 0,
    default_graphical_set = {
      type = "monolith",
      monolith_image = {
        filename = "__UPS-up__/graphics/UPS-up_gui.png",
        priority = "extra-high-no-scale",
        width = 16,
        height = 16,
        x = 0,
        y = 32
      }
    },
    hovered_graphical_set = {
      type = "monolith",
      monolith_image = {
        filename = "__UPS-up__/graphics/UPS-up_gui.png",
        priority = "extra-high-no-scale",
        width = 16,
        height = 16,
        x = 16,
        y = 32
      }
    },
    clicked_graphical_set = {
      type = "monolith",
      monolith_image = {
        filename = "__UPS-up__/graphics/UPS-up_gui.png",
        priority = "extra-high-no-scale",
        width = 16,
        height = 16,
        x = 32,
        y = 32
      }
    },
}