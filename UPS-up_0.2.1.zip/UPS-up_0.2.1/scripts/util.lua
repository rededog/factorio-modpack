if not util then util = {} end
if not util.admins then util.admins = {} end

function util.admins.print(massage)
	for key, player in pairs(game.players) do
		if player.admin then
			player.print(massage)
		end
	end
end