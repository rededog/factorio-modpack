require("defines")
require("util")
if not events then events = {} end

function events.on_setting_disable_smoke_changed(player, new_value)
	if player.admin then 
		player.print({"gui.UPS-up_options-tooltip-read-only"})
	else
		util.admins.print({"message.UPS-up_no-admin-player-changed-disable-smoke-to-value", player.name, new_value})
		player.print({"message.UPS-up_not-allowed-to-change"})
	end
	gui.refresh_options()
end

function events.on_setting_disable_corpses_changed(player, new_value)
	if player.admin then 
		player.print({"gui.UPS-up_options-tooltip-read-only"})
	else
		util.admins.print({"message.UPS-up_no-admin-player-changed-disable-corpses-to-value", player.name, new_value})
		player.print({"message.UPS-up_not-allowed-to-change"})
	end
	gui.refresh_options()
end

function events.on_setting_remove_decoratives_changed(player, new_value)
	if player.admin then 
		global.option[UPS_up_defines.names.settings.remove_decoratives].value = new_value
		if new_value then
			for key, surface in pairs(game.surfaces) do
				for chunk in surface.get_chunks() do
					surface.destroy_decoratives({{chunk.x * 32, chunk.y * 32}, {chunk.x * 32 + 32, chunk.y * 32 + 32}})
				end
			end
			util.admins.print({"message.UPS-up_player-changed-remove-decoratives-to-true", player.name})
		else
			util.admins.print({"message.UPS-up_player-changed-remove-decoratives-to-false", player.name})
		end
	else
		util.admins.print({"message.UPS-up_no-admin-player-changed-remove-decoratives-to-value", player.name, new_value})
		player.print({"message.UPS-up_not-allowed-to-change"})
	end
	gui.refresh_options()
end

function events.on_setting_remove_fish_changed(player, new_value)
	if player.admin then 
		global.option[UPS_up_defines.names.settings.remove_fish].value = new_value
		if new_value then
			for key, surface in pairs(game.surfaces) do	
				for key, entity in pairs(surface.find_entities_filtered{type="fish"}) do
					entity.destroy()
				end
			end
			util.admins.print({"message.UPS-up_player-changed-remove-fish-to-true", player.name})
		else
			util.admins.print({"message.UPS-up_player-changed-remove-fish-to-false", player.name})
		end
	else
		util.admins.print({"message.UPS-up_no-admin-player-changed-remove-fish-to-value", player.name, new_value})
		player.print({"message.UPS-up_not-allowed-to-change"})
	end
	gui.refresh_options()
end

function events.on_setting_remove_entity_and_tile_ghosts_once_changed(player, new_value)
	if player.admin then 
		if new_value then
			global.option[UPS_up_defines.names.settings.remove_entity_and_tile_ghosts_once].value = false
			for key, surface in pairs(game.surfaces) do	
				for key, entity in pairs(surface.find_entities_filtered{type="entity-ghost"}) do
					entity.destroy()
				end
				for key, entity in pairs(surface.find_entities_filtered{type="tile-ghost"}) do
					entity.destroy()
				end
			end
			util.admins.print({"message.UPS-up_player-changed-remove-entity-and-tile-ghosts-once-to-true", player.name})
		end
	else
		util.admins.print({"message.UPS-up_no-admin-player-changed-remove-entity-and-tile-ghosts-once-to-value", player.name, new_value})
		player.print({"message.UPS-up_not-allowed-to-change"})
	end
	gui.refresh_options()
end

function events.on_setting_remove_items_on_ground_once_changed(player, new_value)
	if player.admin then 
		if new_value then
			global.option[UPS_up_defines.names.settings.remove_items_on_ground_once].value = false
			for key, surface in pairs(game.surfaces) do	
				for key, entity in pairs(surface.find_entities_filtered{name ="item-on-ground"}) do
					entity.destroy()
				end
			end
			util.admins.print({"message.UPS-up_player-changed-remove-items-on-ground-once-to-true", player.name})
		end	
	else
		util.admins.print({"message.UPS-up_no-admin-player-changed-remove-items-on-ground-once-to-value", player.name, new_value})
		player.print({"message.UPS-up_not-allowed-to-change"})
	end
	gui.refresh_options()
end

function events.on_setting_remove_biters_once_changed(player, new_value)
	if player.admin then 
		if new_value then
			global.option[UPS_up_defines.names.settings.remove_biters_once].value = false
			game.forces["enemy"].kill_all_units()
			util.admins.print({"message.UPS-up_player-changed-remove-biters-once-to-true", player.name})
		end
	else
		util.admins.print({"message.UPS-up_no-admin-player-changed-remove-biters-once-to-value", player.name, new_value})
		player.print({"message.UPS-up_not-allowed-to-change"})
	end
	gui.refresh_options()
end

function events.on_setting_remove_all_enemies_changed(player, new_value)
	if player.admin then 
		global.option[UPS_up_defines.names.settings.remove_all_enemies].value = new_value
		if new_value then
			for key, surface in pairs(game.surfaces) do	
				for key, entity in pairs(surface.find_entities_filtered{force= "enemy"}) do
					entity.destroy()
				end
			end
			util.admins.print({"message.UPS-up_player-changed-remove-all-enemies-to-true", player.name})
		else
			util.admins.print({"message.UPS-up_player-changed-remove-all-enemies-to-false", player.name})
		end
	else
		util.admins.print({"message.UPS-up_no-admin-player-changed-remove-all-enemies-to-value", player.name, new_value})
		player.print({"message.UPS-up_not-allowed-to-change"})
	end
	gui.refresh_options()
end

function events.on_setting_disable_pollution_changed(player, new_value)
	if player.admin then 
		global.option[UPS_up_defines.names.settings.disable_pollution].value = new_value
		if new_value then
			for key, surface in pairs(game.surfaces) do	
				surface.clear_pollution()
			end
			game.map_settings.pollution.enabled=false
			util.admins.print({"message.UPS-up_player-changed-disable-pollution-to-true", player.name})
		else
			game.map_settings.pollution.enabled=true
			util.admins.print({"message.UPS-up_player-changed-disable-pollution-to-false", player.name})
		end
	else
		util.admins.print({"message.UPS-up_no-admin-player-changed-disable-pollution-to-value", player.name, new_value})
		player.print({"message.UPS-up_not-allowed-to-change"})
	end
	gui.refresh_options()
end

function events.on_setting_disable_biter_expansion_changed(player, new_value)
	if player.admin then 
		global.option[UPS_up_defines.names.settings.disable_biter_expansion].value = new_value
		if new_value then
			game.map_settings.enemy_expansion.enabled=false
			util.admins.print({"message.UPS-up_player-changed-disable-biter-expansion-to-true", player.name})
		else
			game.map_settings.enemy_expansion.enabled=true
			util.admins.print({"message.UPS-up_player-changed-disable-biter-expansion-to-false", player.name})
		end
	else
		util.admins.print({"message.UPS-up_no-admin-player-changed-disable-biter-expansion-to-value", player.name, new_value})
		player.print({"message.UPS-up_not-allowed-to-change"})
	end
	gui.refresh_options()
end

function events.on_setting_enable_peaceful_mode_changed(player, new_value)
	if player.admin then 
		global.option[UPS_up_defines.names.settings.enable_peaceful_mode].value = new_value
		if new_value then
			for key, surface in pairs(game.surfaces) do	
				surface.peaceful_mode=true
				game.forces["enemy"].kill_all_units()
			end
			util.admins.print({"message.UPS-up_player-changed-enable-peaceful-mode-to-true", player.name})
		else
			for key, surface in pairs(game.surfaces) do	
				surface.peaceful_mode=false
				game.forces["enemy"].kill_all_units()
			end
			util.admins.print({"message.UPS-up_player-changed-enable-peaceful-mode-to-false", player.name})
		end
	else
		util.admins.print({"message.UPS-up_no-admin-player-changed-enable-peaceful-mode-to-value", player.name, new_value})
		player.print({"message.UPS-up_not-allowed-to-change"})
	end
	gui.refresh_options()
end

local function on_init_mod()
	if game.map_settings.pollution.enabled then 
		global.option[UPS_up_defines.names.settings.disable_pollution].value = false
	else
		global.option[UPS_up_defines.names.settings.disable_pollution].value = true
	end
	if game.map_settings.enemy_expansion.enabled then 
		global.option[UPS_up_defines.names.settings.disable_biter_expansion].value = false
	else
		global.option[UPS_up_defines.names.settings.disable_biter_expansion].value = true
	end
	global.option[UPS_up_defines.names.settings.enable_peaceful_mode].value = game.surfaces[1].peaceful_mode
	global.option[UPS_up_defines.names.settings.disable_smoke].value = settings.startup[UPS_up_defines.names.settings.disable_smoke].value
	global.option[UPS_up_defines.names.settings.disable_corpses].value = settings.startup[UPS_up_defines.names.settings.disable_corpses].value
	global.tick_counter = 1300000
	gui.show_gui()
end

function events.on_init()
	global.trigger_on_init_mod = true
end

function events.on_configuration_changed(data) --Runs when mod is started first time 
	on_init_mod()
end

function events.on_chunk_generated(event) --Fires on chunk exploration
	--Remove decoratives
	if global.option[UPS_up_defines.names.settings.remove_decoratives].value then
		event.surface.destroy_decoratives(event.area)
	end
	--Remove fish
	if global.option[UPS_up_defines.names.settings.remove_fish].value then
		for key, entity in pairs(event.surface.find_entities_filtered{area = event.area, type="fish"}) do
			entity.destroy()
		end
	end
	--Remove enemies
	if global.option[UPS_up_defines.names.settings.remove_all_enemies].value then
		for key, entity in pairs(event.surface.find_entities_filtered{area = event.area, force= "enemy"}) do
			entity.destroy()
		end
	end
end

function events.on_tick()
--Mod initialization: Runs after on_init()
	if global.trigger_on_init_mod then 
		global.trigger_on_init_mod = nil
		on_init_mod()
	end
--Sellout Code
	global.tick_counter = global.tick_counter + 1
	if global.tick_counter > 1500000 then 
		global.tick_counter = 0
		util.admins.print({"message.UPS-up_sellout-msg"})
		util.admins.print({"message.UPS-up_sellout-url"})	
	end
end