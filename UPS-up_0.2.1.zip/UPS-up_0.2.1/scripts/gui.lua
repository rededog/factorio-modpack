if not gui then gui = {} end

function gui.show_options(player)
	if not player.gui.center["UPS-up_options-frame"] then
		-- Title
		player.gui.center.add{type = "frame", 			name = "UPS-up_options-frame", 								direction = "vertical", 									caption = {"gui.UPS-up_options-title"}}
		local options_frame = player.gui.center["UPS-up_options-frame"]	
		-- Heading	
		options_frame.add{type = "label", 				name = "UPS-up_options-subtitle", 							caption = {"gui.UPS-up_options-subtitle"}}
		options_frame["UPS-up_options-subtitle"].style.font = "default-bold"
		-- Table
		options_frame.add{type = "table", 				name = "UPS-up_options-table", 								colspan  = 4}
		local options_table = options_frame["UPS-up_options-table"]
		-- Column-titles
		options_table.add{type = "label", 				name = "UPS-up_options-checkbox-column-name", 				caption = {"gui.UPS-up_options-empty"}}
		options_table.add{type = "label", 				name = "UPS-up_options-description-column-name", 			caption = {"gui.UPS-up_options-empty"}}
		options_table.add{type = "label", 				name = "UPS-up_options-ups-column-name", 					caption = {"gui.UPS-up_options-ups-column-caption"}, 		tooltip = {"gui.UPS-up_options-ups-column-tooltip"}}
		options_table.add{type = "label",				name = "UPS-up_options-file-size-column-name", 				caption = {"gui.UPS-up_options-file-size-column-caption"},	tooltip = {"gui.UPS-up_options-file-size-column-tooltip"}}
		-- Option-Rows
		for key, option in pairs(global.option) do	
			if option.type == "checkbox" then
				if option.read_only then
					options_table.add{type = "checkbox",name = "UPS-up_options-checkbox-" .. option.name, 			state = option.value, 										tooltip = {"gui.UPS-up_options-tooltip-read-only"}}	
				else
					options_table.add{type = "checkbox",name = "UPS-up_options-checkbox-" .. option.name, 			state = option.value}	
				end
				options_table.add{type = "label", 		name = "UPS-up_options-description-" .. option.name, 		caption = {"mod-setting-name." .. option.name}, 			tooltip = {"mod-setting-description." .. option.name}}
				if option.read_only then
					options_table["UPS-up_options-description-" .. option.name].style.font_color = {r = 0.6, g = 0.6, b = 0.6}
				end
				options_table.add{type = "label", 		name = "UPS-up_options-expected-ups-" .. option.name, 		caption = {"mod-setting-expected-ups-improvement." .. option.name}}
				options_table.add{type = "label", 		name = "UPS-up_options-expected-file-size-" .. option.name, caption = {"mod-setting-expected-file-size-improvement." .. option.name}}
			end
			if option.type == "button" then
				options_table.add{type = "button", 		name = "UPS-up_options-button-" .. option.name, 			style = "UPS-up_options-button"}
				options_table.add{type = "label", 		name = "UPS-up_options-description-" .. option.name, 		caption = {"mod-setting-name." .. option.name}, 			tooltip = {"mod-setting-description." .. option.name}}
				options_table.add{type = "label", 		name = "UPS-up_options-expected-ups-" .. option.name, 		caption = {"mod-setting-expected-ups-improvement." .. option.name}}
				options_table.add{type = "label", 		name = "UPS-up_options-expected-file-size-" .. option.name,	caption = {"mod-setting-expected-file-size-improvement." .. option.name}}
			end
		end
		-- Buttons
		options_frame.add{type = "table", 				name = "UPS-up_options-buttontable", 						colspan  = 3}
		local options_buttontable = options_frame["UPS-up_options-buttontable"]	
		-- Done button
		options_buttontable.add{type = "button", 		name = "UPS-up_options-button-done", 						caption = {"gui.UPS-up_options-button-done"}}	
		options_buttontable["UPS-up_options-button-done"].style.right_padding = 10
		options_buttontable["UPS-up_options-button-done"].style.left_padding = 10
		-- Spaceholder
		options_buttontable.add{type = "label",  		name = "UPS-up_options-label-space", 						caption = "                                                                       "}
		-- Support this mod button
		options_buttontable.add{type = "button", 		name = "UPS-up_options-button-support-this-mod", 			caption = {"gui.UPS-up_options-button-support-this-mod"}}	
		options_buttontable["UPS-up_options-button-support-this-mod"].style.right_padding = 10
		options_buttontable["UPS-up_options-button-support-this-mod"].style.left_padding = 10
	end
end

function gui.hide_options(player)
	if (player.gui.center["UPS-up_options-frame"]) then
		player.gui.center["UPS-up_options-frame"].destroy()
	end
end

function gui.show_gui()
	for key, player in pairs(game.players) do
		if (not player.gui.top["UPS-up_gui-top-button"]) then
			player.gui.top.add{type = "button", name = "UPS-up_gui-top-button", style = "UPS-up_gui-top-button"}
		end
	end
end

function gui.refresh_options()
	for key, player in pairs(game.players) do
		if (player.gui.center["UPS-up_options-frame"]) then
			gui.hide_options(player)
			gui.show_options(player)
		end
	end
end

function gui.swap_options(player)
	if (player.gui.center["UPS-up_options-frame"]) then
		gui.hide_options(player)
	else
		gui.show_options(player)
	end
end

function gui.show_support(player)
	if not player.gui.center["UPS-up_support-frame"] then
		-- Title
		player.gui.center.add{type = "frame", 	name = "UPS-up_support-frame", 				direction = "vertical", caption = {"gui.UPS-up_support-title"}}
		local support_frame = player.gui.center["UPS-up_support-frame"]
		-- Heading	
		support_frame.add{type = "table", 		name = "UPS-up_support-table", 				colspan  = 1}
		local support_table = support_frame["UPS-up_support-table"]
		support_table.add{type = "label", 		name = "UPS-up_support-label-description1", caption = {"gui.UPS-up_support-label-description1"}}
		support_table.add{type = "label", 		name = "UPS-up_support-label-description2", caption = {"gui.UPS-up_support-label-description2"}}
		support_table.add{type = "textfield",	name = "UPS-up_support-text-box-text", 		text = "www.patreon.com/UPS"}
		-- Got-it button
		support_table.add{type = "button", 		name = "UPS-up_support-button-got-it", 		caption = {"gui.UPS-up_support-button-got-it"}}	
		support_table["UPS-up_support-button-got-it"].style.right_padding = 10
		support_table["UPS-up_support-button-got-it"].style.left_padding = 10
	end
end

function gui.hide_support(player)
	if (player.gui.center["UPS-up_support-frame"]) then
		player.gui.center["UPS-up_support-frame"].destroy()
	end
end

function gui.on_gui_click(event)
	local gui_element_name = event.element.name
	local player = game.players[event.element.player_index]
-- UPS-up Top-mainbutton clicked
	if gui_element_name == "UPS-up_gui-top-button" then
		gui.swap_options(player)
-- Option changed
	--Disable smoke
	elseif gui_element_name == "UPS-up_options-checkbox-" .. UPS_up_defines.names.settings.disable_smoke then
		events.on_setting_disable_smoke_changed(			player, player.gui.center["UPS-up_options-frame"]["UPS-up_options-table"]["UPS-up_options-checkbox-" .. UPS_up_defines.names.settings.disable_smoke].state)
	--Disable corpses
	elseif gui_element_name == "UPS-up_options-checkbox-" .. UPS_up_defines.names.settings.disable_corpses then
		events.on_setting_disable_corpses_changed(			player, player.gui.center["UPS-up_options-frame"]["UPS-up_options-table"]["UPS-up_options-checkbox-" .. UPS_up_defines.names.settings.disable_corpses].state)
	--Remove decoratives permanently
	elseif gui_element_name == "UPS-up_options-checkbox-" .. UPS_up_defines.names.settings.remove_decoratives then
		events.on_setting_remove_decoratives_changed(		player, player.gui.center["UPS-up_options-frame"]["UPS-up_options-table"]["UPS-up_options-checkbox-" .. UPS_up_defines.names.settings.remove_decoratives].state)
	--Remove fish permanently
	elseif gui_element_name == "UPS-up_options-checkbox-" .. UPS_up_defines.names.settings.remove_fish then
		events.on_setting_remove_fish_changed(player, 		player.gui.center["UPS-up_options-frame"]["UPS-up_options-table"]["UPS-up_options-checkbox-" .. UPS_up_defines.names.settings.remove_fish].state)
	--Remove entity and tile ghosts (once)
	elseif gui_element_name == "UPS-up_options-button-"   .. UPS_up_defines.names.settings.remove_entity_and_tile_ghosts_once then
		events.on_setting_remove_entity_and_tile_ghosts_once_changed(	player, true)
	--Remove items on ground (once)
	elseif gui_element_name == "UPS-up_options-button-"   .. UPS_up_defines.names.settings.remove_items_on_ground_once then
		events.on_setting_remove_items_on_ground_once_changed(			player, true)
	--Remove biters (once)
	elseif gui_element_name == "UPS-up_options-button-"   .. UPS_up_defines.names.settings.remove_biters_once then
		events.on_setting_remove_biters_once_changed(					player, true)
	--Remove all enemies permanently
	elseif gui_element_name == "UPS-up_options-checkbox-" .. UPS_up_defines.names.settings.remove_all_enemies then
		events.on_setting_remove_all_enemies_changed(		player, player.gui.center["UPS-up_options-frame"]["UPS-up_options-table"]["UPS-up_options-checkbox-" .. UPS_up_defines.names.settings.remove_all_enemies].state)
	--Disable pollution
	elseif gui_element_name == "UPS-up_options-checkbox-" .. UPS_up_defines.names.settings.disable_pollution then
		events.on_setting_disable_pollution_changed(		player, player.gui.center["UPS-up_options-frame"]["UPS-up_options-table"]["UPS-up_options-checkbox-" .. UPS_up_defines.names.settings.disable_pollution].state)
	--Disable biter expansion
	elseif gui_element_name == "UPS-up_options-checkbox-" .. UPS_up_defines.names.settings.disable_biter_expansion then
		events.on_setting_disable_biter_expansion_changed(	player, player.gui.center["UPS-up_options-frame"]["UPS-up_options-table"]["UPS-up_options-checkbox-" .. UPS_up_defines.names.settings.disable_biter_expansion].state)
	--Enable peaceful mode
	elseif gui_element_name == "UPS-up_options-checkbox-" .. UPS_up_defines.names.settings.enable_peaceful_mode then
		events.on_setting_enable_peaceful_mode_changed(		player, player.gui.center["UPS-up_options-frame"]["UPS-up_options-table"]["UPS-up_options-checkbox-" .. UPS_up_defines.names.settings.enable_peaceful_mode].state)
-- Option button clicked
	-- Done
	elseif gui_element_name == "UPS-up_options-button-done" then 
		gui.hide_options(player)
	-- Support this Mod
	elseif gui_element_name == "UPS-up_options-button-support-this-mod" then 
		gui.hide_options(player)
		gui.show_support(player)
-- Support button clicked
	-- Got it!
	elseif gui_element_name == "UPS-up_support-button-got-it" then 
		gui.hide_support(player)
		gui.show_options(player)
	end
end