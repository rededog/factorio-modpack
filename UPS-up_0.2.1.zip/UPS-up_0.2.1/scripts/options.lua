require("defines")
if not global.option									then global.option = {} end

-- Disable smoke
local temp_name = UPS_up_defines.names.settings.disable_smoke
if not global.option[temp_name] then
global.option[temp_name] =
	{
		name = temp_name,
		type = "checkbox",
		value = true,
		read_only = true,
	}
end

-- Disable corpses
local temp_name = UPS_up_defines.names.settings.disable_corpses
if not global.option[temp_name] then
global.option[temp_name] =
	{
		name = temp_name,
		type = "checkbox",
		value = true,
		read_only = true,
	}
end

-- Remove decoratives
local temp_name = UPS_up_defines.names.settings.remove_decoratives
if not global.option[temp_name] then
global.option[temp_name] =
	{
		name = temp_name,
		type = "checkbox",
		value = false,
		read_only = false,
	}
end

-- Remove fish
local temp_name = UPS_up_defines.names.settings.remove_fish
if not global.option[temp_name] then
global.option[temp_name] =
	{
		name = temp_name,
		type = "checkbox",
		value = false,
		read_only = false,
	}
end

-- Remove entity and tile ghosts
local temp_name = UPS_up_defines.names.settings.remove_entity_and_tile_ghosts_once
if not global.option[temp_name] then
global.option[temp_name] =
	{
		name = temp_name,
		type = "button",
	}
end

-- Remove items on ground once
local temp_name = UPS_up_defines.names.settings.remove_items_on_ground_once
if not global.option[temp_name] then
global.option[temp_name] =
	{
		name = temp_name,
		type = "button",
	}
end

-- Remove biters once
local temp_name = UPS_up_defines.names.settings.remove_biters_once
if not global.option[temp_name] then
global.option[temp_name] =
	{
		name = temp_name,
		type = "button",
	}
end

-- Remove all enemies
local temp_name = UPS_up_defines.names.settings.remove_all_enemies
if not global.option[temp_name] then
global.option[temp_name] =
	{
		name = temp_name,
		type = "checkbox",
		value = false,
		read_only = false,
	}
end

-- Disable pollution
local temp_name = UPS_up_defines.names.settings.disable_pollution
if not global.option[temp_name] then
global.option[temp_name] =
	{
		name = temp_name,
		type = "checkbox",
		value = false,
		read_only = false,
	}
end

-- Disable biter expansion
local temp_name = UPS_up_defines.names.settings.disable_biter_expansion
if not global.option[temp_name] then
global.option[temp_name] =
	{
		name = temp_name,
		type = "checkbox",
		value = false,
		read_only = false,
	}
end

-- Enable peaceful mode
local temp_name = UPS_up_defines.names.settings.enable_peaceful_mode
if not global.option[temp_name] then
global.option[temp_name] =
	{
		name = temp_name,
		type = "checkbox",
		value = false,
		read_only = false,
	}
end