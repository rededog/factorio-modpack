UPS_up_defines = {}
UPS_up_defines.mod_directory = "__UPS-up__"
UPS_up_defines.name_prefix = "UPS-up_"
UPS_up_defines.names = {}

-- Setting names
UPS_up_defines.names.settings =
{
	disable_smoke						= UPS_up_defines.name_prefix .. "disable-smoke",
	disable_corpses						= UPS_up_defines.name_prefix .. "disable-corpses",
	remove_decoratives					= UPS_up_defines.name_prefix .. "remove-decoratives",
	remove_fish							= UPS_up_defines.name_prefix .. "remove-fish",
	remove_entity_and_tile_ghosts_once	= UPS_up_defines.name_prefix .. "remove-entity-and-tile-ghosts-once",
	remove_items_on_ground_once			= UPS_up_defines.name_prefix .. "remove-items-on-ground-once",
	remove_biters_once					= UPS_up_defines.name_prefix .. "remove-biters-once",
	remove_all_enemies					= UPS_up_defines.name_prefix .. "remove-all-enemies",
	disable_pollution					= UPS_up_defines.name_prefix .. "disable-pollution",
	disable_biter_expansion				= UPS_up_defines.name_prefix .. "disable-biter-expansion",
	enable_peaceful_mode				= UPS_up_defines.name_prefix .. "enable-peaceful-mode",
}