data:extend({
  {
    type = "technology",
    name = "blasting-charges",
    icon = "__Explosive Excavation__/graphics/technology/blasting-explosives.png",
    icon_size = 128,
    prerequisites = {"cliff-explosives", "landfill"},
    unit =
    {
      count = 150,
      ingredients =
      {
        {"science-pack-1", 1},
        {"science-pack-2", 1},
        {"military-science-pack", 1}
      },
      time = 15
    },
    effects =
    {
      {
        type = "unlock-recipe",
        recipe = "blasting-charge"
      }
    },
    order = "b-d"
  }
})