-- if angelsmods.tech then
	-- require("prototypes.angels-tech-override")
-- end

-- angelsmods.functions.OV.execute()