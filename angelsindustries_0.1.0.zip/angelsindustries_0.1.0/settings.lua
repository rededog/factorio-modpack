data:extend(
{
   {
    type = "bool-setting",
    name = "angels-enable-industries",
    setting_type = "startup",
    default_value = false,
    order = "a",
   },
   {
    type = "bool-setting",
    name = "angels-enable-tech",
    setting_type = "startup",
    default_value = false,
    order = "a",
   },
}
)


