data:extend({
	{
		type = "int-setting",
		name = "flare-stack-fluid-rate",
		setting_type = "startup",
		default_value = 10,
    minimum_value = 1
	}
})