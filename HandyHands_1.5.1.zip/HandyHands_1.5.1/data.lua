data:extend({
  {
    type = "custom-input",
    name = "handyhands-increase",
    key_sequence = "U",
    consuming = "none"
  },{
    type = "custom-input",
    name = "handyhands-decrease",
    key_sequence = "J",
    consuming = "none"
  }
})