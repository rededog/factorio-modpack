data:extend(
{
  {
    type = "recipe",
    name = "cellulose-fiber-raw-wood",
    category = "crafting",
	subgroup = "bio-wood",
	enabled = "false",
    energy_required = 2,
    ingredients ={
	{type="item", name="raw-wood", amount=1},
	},
    results=
    {
      {type="item", name="cellulose-fiber", amount=4},
    },
    icon = "__angelsbioprocessing__/graphics/icons/cellulose-fiber-raw-wood.png",
	icon_size = 32,
    order = "a",
  },
   {
    type = "recipe",
    name = "wood-from-cellulose",
    category = "advanced-crafting",
	subgroup = "bio-wood",
	enabled = "false",
    energy_required = 2,
    ingredients ={
		{type="item", name="cellulose-fiber", amount=4},
		{type="item", name="paste-cellulose", amount=2},
	},
    results=
    {
      {type="item", name="wood", amount=5},
    },
    icon = "__angelsbioprocessing__/graphics/icons/wood-cellulose.png",
	icon_size = 32,
    order = "b",
  },
  {
    type = "recipe",
    name = "wood-pellets",
    category = "crafting",
	subgroup = "bio-wood",
	enabled = "false",
    energy_required = 4,
    ingredients ={
		{type="item", name="cellulose-fiber", amount=12},
	},
    results=
    {
      {type="item", name="wood-pellets", amount=2},
    },
    icon = "__angelsbioprocessing__/graphics/icons/wood-pellets.png",
	icon_size = 32,
    order = "c",
  },
  {
    type = "recipe",
    name = "wood-bricks",
    category = "crafting",
	subgroup = "bio-wood",
	enabled = "false",
    energy_required = 2,
    ingredients ={
		{type="item", name="wood-pellets", amount=8},
	},
    results=
    {
      {type="item", name="wood-bricks", amount=4},
    },
    icon = "__angelsbioprocessing__/graphics/icons/wood-bricks.png",
	icon_size = 32,
    order = "d",
  },
  {
    type = "recipe",
    name = "gas-carbon-dioxide-from-wood",
    category = "liquifying",
	subgroup = "bio-wood",
	enabled = "false",
    energy_required = 2,
    ingredients ={
		{type="item", name="wood-pellets", amount=1},
	},
    results=
    {
      {type="fluid", name="gas-carbon-dioxide", amount=70},
    },
    icon = "__angelspetrochem__/graphics/icons/gas-carbon-dioxide.png",
	icon_size = 32,
    order = "e",
  },
--PAPER
	--T1
    {
    type = "recipe",
    name = "solid-wood-pulp",
    category = "crafting",
	subgroup = "bio-paper",
	enabled = "false",
    energy_required = 4,
    ingredients ={
      {type="item", name="cellulose-fiber", amount=4},
      {type="item", name="solid-alginic-acid", amount=1},
	},
    results=
    {
      {type="item", name="solid-wood-pulp", amount=1},
    },
	icons = {
		{
			icon = "__angelsbioprocessing__/graphics/icons/solid-wood-pulp.png",
		},
		{
			icon = "__angelspetrochem__/graphics/icons/num_1.png",
			tint = {r = 0.2, g = 1, b = 0.2, a = 0.5},
			scale = 0.32,
			shift = {-12, -12},
		}
	},	
	icon_size = 32,
    order = "a",
    },
	--T2 SULFITE PROCESS
    {
    type = "recipe",
    name = "liquid-pulping-liquor",
    category = "advanced-chemistry",
	subgroup = "bio-paper",
	enabled = "false",
    energy_required = 4,
    ingredients ={
      {type="fluid", name="gas-sulfur-dioxide", amount=4},
      {type="fluid", name="gas-oxygen", amount=1},
      {type="fluid", name="water", amount=1},
	},
    results=
    {
      {type="fluid", name="liquid-pulping-liquor", amount=1},
    },    
	--icon = "__angelsbioprocessing__/graphics/icons/solid-wood-pulp.png",
	icon_size = 32,
    order = "b",
    },
    {
    type = "recipe",
    name = "brown-liquor-recovery",
    category = "liquifying",
	subgroup = "bio-paper",
	enabled = "false",
    energy_required = 4,
    ingredients ={
      {type="fluid", name="liquid-brown-liquor", amount=1},
      {type="item", name="solid-sodium-hydroxide", amount=4},
	},
    results=
    {
      {type="item", name="solid-sodium-sulfate", amount=1},
      {type="fluid", name="water-red-waste", amount=1},
    },   
	icons = {
		{
			icon = "__angelspetrochem__/graphics/icons/solid-sodium-sulfate.png",
		},
		{
			icon = "__angelsbioprocessing__/graphics/icons/liquid-brown-liquor.png",
			scale = 0.4375,
			shift = { -10, -10},
		},
	},	
	icon_size = 32,
    order = "c",
    },	
    {
    type = "recipe",
    name = "sulfite-pulping",
    category = "advanced-chemistry",
	subgroup = "bio-paper",
	enabled = "false",
    energy_required = 4,
    ingredients ={
      {type="fluid", name="liquid-pulping-liquor", amount=1},
      {type="fluid", name="gas-ammonia", amount=1},
      {type="fluid", name="water", amount=1},
	},
    results=
    {
      {type="item", name="solid-wood-pulp", amount=1},
      {type="fluid", name="liquid-brown-liquor", amount=1},
    },  
	icons = {
		{
			icon = "__angelsbioprocessing__/graphics/icons/solid-wood-pulp.png",
		},
		{
			icon = "__angelspetrochem__/graphics/icons/num_2.png",
			tint = {r = 0.2, g = 1, b = 0.2, a = 0.5},
			scale = 0.32,
			shift = {-12, -12},
		}
	},	
	icon_size = 32,
    order = "d",
    },
	--T3 KRAFT PROCESS (SULFATE PROCESS)
    {
    type = "recipe",
    name = "liquid-white-liquor",
    category = "liquifying",
	subgroup = "bio-paper",
	enabled = "false",
    energy_required = 4,
    ingredients ={
      {type="item", name="solid-sodium-hydroxide", amount=4},
      {type="item", name="solid-sodium-sulfate", amount=1},
      {type="fluid", name="water", amount=1},
	},
    results=
    {
      {type="fluid", name="liquid-white-liquor", amount=1},
    },   
	--icon = "__angelsbioprocessing__/graphics/icons/solid-wood-pulp.png",
	icon_size = 32,
    order = "e",
    },	
    {
    type = "recipe",
    name = "kraft-recovery",
    category = "liquifying",
	subgroup = "bio-paper",
	enabled = "false",
    energy_required = 4,
    ingredients ={
      {type="fluid", name="liquid-black-liquor", amount=1},
	},
    results=
    {
      {type="fluid", name="liquid-green-liquor", amount=1},	--+energy gain
    },  
	icon = "__angelsbioprocessing__/graphics/icons/liquid-green-liquor.png",
	icon_size = 32,
    order = "f",
    },
    {
    type = "recipe",
    name = "kraft-causting",
    category = "chemistry",
	subgroup = "bio-paper",
	enabled = "false",
    energy_required = 4,
    ingredients ={
      {type="fluid", name="liquid-green-liquor", amount=1},
      {type="fluid", name="water", amount=1},
      {type="item", name="solid-lime", amount=1},
	},
    results=
    {
      {type="fluid", name="liquid-white-liquor", amount=1},
      {type="item", name="solid-limestone", amount=1},
    },
    icon = "__angelsbioprocessing__/graphics/icons/liquid-white-liquor.png",
	icon_size = 32,
    order = "g",
    },	
    {
    type = "recipe",
    name = "kraft-cooking-washing",
    category = "liquifying",
	subgroup = "bio-paper",
	enabled = "false",
    energy_required = 4,
    ingredients ={
      {type="item", name="cellulose-fiber", amount=4},
      {type="fluid", name="liquid-white-liquor", amount=1},
	},
    results=
    {
      {type="item", name="solid-wood-pulp", amount=1},
      {type="fluid", name="liquid-black-liquor", amount=1},
    },  
	icons = {
		{
			icon = "__angelsbioprocessing__/graphics/icons/solid-wood-pulp.png",
		},
		{
			icon = "__angelspetrochem__/graphics/icons/num_3.png",
			tint = {r = 0.2, g = 1, b = 0.2, a = 0.5},
			scale = 0.32,
			shift = {-12, -12},
		}
	},	
	icon_size = 32,
    order = "h",
    },	
	--BLEACHING
    {
    type = "recipe",
    name = "paper-bleaching-1",
    category = "crafting",
	subgroup = "bio-paper",
	enabled = "false",
    energy_required = 4,
    ingredients ={
      {type="item", name="solid-wood-pulp", amount=3},
	},
    results=
    {
      {type="item", name="solid-paper", amount=1},
    }, 
	--main_product = "solid-paper",
	icons = {
		{
			icon = "__angelsbioprocessing__/graphics/icons/solid-paper.png",
		},
		{
			icon = "__angelspetrochem__/graphics/icons/num_1.png",
			tint = {r = 0.8, g = 0.8, b = 0.8, a = 0.5},
			scale = 0.32,
			shift = {-12, -12},
		}
	},	
	icon_size = 32,
    order = "i",
    },
    {
    type = "recipe",
    name = "paper-bleaching-2",
    category = "liquifying",
	subgroup = "bio-paper",
	enabled = "false",
    energy_required = 4,
    ingredients ={
      {type="item", name="solid-wood-pulp", amount=3},
      {type="item", name="solid-sodium-hydroxide", amount=1},
      {type="fluid", name="gas-chlorine", amount=1},
	},
    results=
    {
      {type="item", name="solid-paper", amount=2},
      {type="item", name="solid-sodium-hypochlorite", amount=1},
    },  
	--main_product = "solid-paper",
	icons = {
		{
			icon = "__angelsbioprocessing__/graphics/icons/solid-paper.png",
		},
		{
			icon = "__angelspetrochem__/graphics/icons/num_2.png",
			tint = {r = 0.8, g = 0.8, b = 0.8, a = 0.5},
			scale = 0.32,
			shift = {-12, -12},
		}
	},	
	icon_size = 32,
    order = "j",
    },
    {
    type = "recipe",
    name = "paper-bleaching-3",
    category = "advanced-chemistry",
	subgroup = "bio-paper",
	enabled = "false",
    energy_required = 4,
    ingredients ={
      {type="item", name="solid-wood-pulp", amount=3},
      {type="item", name="solid-sodium-hydroxide", amount=1},
      {type="fluid", name="gas-oxygen", amount=1},
      {type="fluid", name="gas-sulfur-dioxide", amount=1},
      {type="fluid", name="water", amount=1},
	},
    results=
    {
      {type="item", name="solid-paper", amount=3},
      {type="item", name="solid-sodium-carbonate", amount=1},
      {type="fluid", name="water-yellow-waste", amount=1},
    },
	--main_product = "solid-paper",
	icons = {
		{
			icon = "__angelsbioprocessing__/graphics/icons/solid-paper.png",
		},
		{
			icon = "__angelspetrochem__/graphics/icons/num_3.png",
			tint = {r = 0.8, g = 0.8, b = 0.8, a = 0.5},
			scale = 0.32,
			shift = {-12, -12},
		}
	},	
	icon_size = 32,
    order = "k",
    },	
	--PRODUCTS
    {
    type = "recipe",
    name = "circuit-paper-board",
    icon = "__angelsbioprocessing__/graphics/icons/wood-fiber-board.png",
    category = "advanced-crafting",
	subgroup = "bio-paper",
	enabled = "false",
    energy_required = 4,
    ingredients ={
      {type="item", name="solid-paper", amount=1},
	},
    results=
    {
      {type="item", name="circuit-wood-fiber-board", amount=2},
    },
	icon_size = 32,
    order = "l",
    },
--TREES
    {
    type = "recipe",
    name = "temperate-tree-aboretum",
    category = "angels-tree-temperate",
	subgroup = "bio-aboretum",
	enabled = "false",
    energy_required = 15,
    ingredients ={
	},
    results=
    {
      {type="item", name="raw-wood", amount=10},
      {type="item", name="bio-resin", amount=1},
    },
	icons = {
		{
			icon = "__angelsbioprocessing__/graphics/icons/tree-temperate-icon.png",
		}
	},	
	icon_size = 32,
    order = "a",
    },
    {
    type = "recipe",
    name = "bio-resin",
    category = "liquifying",
	subgroup = "bio-aboretum",
	enabled = "false",
    energy_required = 4,
    ingredients ={
      {type="fluid", name="gas-ethanol", amount=20},
      {type="item", name="bio-resin", amount=2},
	},
    results=
    {
      {type="fluid", name="liquid-resin", amount=5},
    },
	icons = {
		{
			icon = "__angelspetrochem__/graphics/icons/liquid-resin.png",
		},
		{
			icon = "__angelsbioprocessing__/graphics/icons/tree-temperate-icon.png",
			scale = 0.5,
			shift = {-12, -12},
		}
	},	
	icon_size = 32,
    order = "b",
    },
    {
    type = "recipe",
    name = "swamp-tree-aboretum",
    category = "angels-tree-swamp",
	subgroup = "bio-aboretum",
	enabled = "false",
    energy_required = 15,
    ingredients ={
	},
    results=
    {
      {type="item", name="raw-wood", amount=10},
      {type="item", name="bio-plastic", amount=1},
    },
	icons = {
		{
			icon = "__angelsbioprocessing__/graphics/icons/tree-swamp-icon.png",
		}
	},	
	icon_size = 32,
    order = "c",
    },
    {
    type = "recipe",
    name = "bio-plastic",
    category = "liquifying",
	subgroup = "bio-aboretum",
	enabled = "false",
    energy_required = 4,
    ingredients ={
      {type="fluid", name="gas-acetone", amount=20},
      {type="item", name="bio-plastic", amount=2},
	},
    results=
    {
      {type="fluid", name="liquid-plastic", amount=5},
    },
	icons = {
		{
			icon = "__angelspetrochem__/graphics/icons/liquid-plastic.png",
		},
		{
			icon = "__angelsbioprocessing__/graphics/icons/tree-swamp-icon.png",
			scale = 0.5,
			shift = {-12, -12},
		}
	},	
	icon_size = 32,
    order = "d",
    },
}
)