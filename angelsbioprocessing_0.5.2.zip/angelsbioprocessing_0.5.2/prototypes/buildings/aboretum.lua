  data:extend(
  {
  {
    type = "item",
    name = "bio-aboretum-temperate",
	icons = {
		{
			icon = "__angelsbioprocessing__/graphics/icons/bio-aboretum.png",
		},
		{
			icon = "__angelsbioprocessing__/graphics/icons/tree-temperate-icon.png",
		}
	},	
	icon_size = 32,
    flags = {"goes-to-quickbar"},
    subgroup = "bio-processing-buildings-a",
    order = "e",
    place_result = "bio-aboretum-temperate",
    stack_size = 10,
  },
  {
    type = "assembling-machine",
    name = "bio-aboretum-temperate",
	icons = {
		{
			icon = "__angelsbioprocessing__/graphics/icons/bio-aboretum.png",
		},
		{
			icon = "__angelsbioprocessing__/graphics/icons/tree-temperate-icon.png",
		}
	},	
	icon_size = 32,
    flags = {"placeable-neutral","player-creation"},
    minable = {mining_time = 1, result = "bio-aboretum-temperate"},
    max_health = 300,
	corpse = "big-remnants",
    dying_explosion = "medium-explosion",
    collision_box = {{-3.4, -3.4}, {3.4, 3.4}},
    selection_box = {{-3.5, -4.5}, {3.5, 3.5}},
	fast_replaceable_group= "bio-aboretum-temperate",
    module_specification =
    {
      module_slots = 2
    },
    allowed_effects = {"consumption", "speed", "productivity", "pollution"},
    crafting_categories = {"angels-tree-temperate"},
    crafting_speed = 0.5,
    energy_source =
    {
      type = "electric",
      usage_priority = "secondary-input",
      emissions = -0.02 / 2
    },
    energy_usage = "100kW",
    ingredient_count = 4,
    animation={
		layers={
		  {
			filename = "__angelsbioprocessing__/graphics/entity/trees/bio-aboretum-shadow.png",
			width = 288,
			height = 352,
			line_length = 1,
			frame_count = 1,
			shift = {0, -1},
		  },
		  {
			filename = "__angelsbioprocessing__/graphics/entity/trees/bio-aboretum-back.png",
			width = 288,
			height = 352,
			line_length = 1,
			frame_count = 1,
			shift = {0, -1},
		  },
		  {
			filename = "__angelsbioprocessing__/graphics/entity/trees/tree-1-a.png",
			width = 256,
			height = 256,
			line_length = 1,
			frame_count = 1,
			shift = {0.5, -1.5},
		  },
		  {
			filename = "__angelsbioprocessing__/graphics/entity/trees/bio-aboretum-front.png",
			width = 288,
			height = 352,
			line_length = 1,
			frame_count = 1,
			shift = {0, -1},
		  },
		}
	},
    vehicle_impact_sound =  { filename = "__base__/sound/car-metal-impact.ogg", volume = 0.65 },
    working_sound =
    {
      sound = { filename = "__base__/sound/chemical-plant.ogg" },
      idle_sound = { filename = "__base__/sound/idle1.ogg", volume = 0.6 },
      apparent_volume = 2.5,
    },
  },
  {
    type = "item",
    name = "bio-aboretum-swamp",
	icons = {
		{
			icon = "__angelsbioprocessing__/graphics/icons/bio-aboretum.png",
		},
		{
			icon = "__angelsbioprocessing__/graphics/icons/tree-swamp-icon.png",
		}
	},	
	icon_size = 32,
    flags = {"goes-to-quickbar"},
    subgroup = "bio-processing-buildings-a",
    order = "e",
    place_result = "bio-aboretum-swamp",
    stack_size = 10,
  },
  {
    type = "assembling-machine",
    name = "bio-aboretum-swamp",
	icons = {
		{
			icon = "__angelsbioprocessing__/graphics/icons/bio-aboretum.png",
		},
		{
			icon = "__angelsbioprocessing__/graphics/icons/tree-swamp-icon.png",
		}
	},	
	icon_size = 32,
    flags = {"placeable-neutral","player-creation"},
    minable = {mining_time = 1, result = "bio-aboretum-swamp"},
    max_health = 300,
	corpse = "big-remnants",
    dying_explosion = "medium-explosion",
    collision_box = {{-3.4, -3.4}, {3.4, 3.4}},
    selection_box = {{-3.5, -4.5}, {3.5, 3.5}},
	fast_replaceable_group= "bio-aboretum-swamp",
    module_specification =
    {
      module_slots = 2
    },
    allowed_effects = {"consumption", "speed", "productivity", "pollution"},
    crafting_categories = {"angels-tree-swamp"},
    crafting_speed = 0.5,
    energy_source =
    {
      type = "electric",
      usage_priority = "secondary-input",
      emissions = -0.02 / 2
    },
    energy_usage = "100kW",
    ingredient_count = 4,
    animation={
		layers={
		  {
			filename = "__angelsbioprocessing__/graphics/entity/trees/bio-aboretum-shadow.png",
			width = 288,
			height = 352,
			line_length = 1,
			frame_count = 1,
			shift = {0, -1},
		  },
		  {
			filename = "__angelsbioprocessing__/graphics/entity/trees/bio-aboretum-back.png",
			width = 288,
			height = 352,
			line_length = 1,
			frame_count = 1,
			shift = {0, -1},
		  },
		  {
			filename = "__angelsbioprocessing__/graphics/entity/trees/tree-2-a.png",
			width = 256,
			height = 256,
			line_length = 1,
			frame_count = 1,
			shift = {1, -2},
		  },
		  {
			filename = "__angelsbioprocessing__/graphics/entity/trees/bio-aboretum-front.png",
			width = 288,
			height = 352,
			line_length = 1,
			frame_count = 1,
			shift = {0, -1},
		  },
		}
	},
    vehicle_impact_sound =  { filename = "__base__/sound/car-metal-impact.ogg", volume = 0.65 },
    working_sound =
    {
      sound = { filename = "__base__/sound/chemical-plant.ogg" },
      idle_sound = { filename = "__base__/sound/idle1.ogg", volume = 0.6 },
      apparent_volume = 2.5,
    },
  },
  }
  )