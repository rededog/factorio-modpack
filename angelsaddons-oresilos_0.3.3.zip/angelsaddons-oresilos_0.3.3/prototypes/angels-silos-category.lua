data:extend(
{
  {
    type = "item-subgroup",
    name = "angels-silos",
	group = "logistics",
	order = "zc",
  },
  }
  )