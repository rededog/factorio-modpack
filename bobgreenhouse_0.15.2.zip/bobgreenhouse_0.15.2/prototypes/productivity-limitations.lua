bobmods.lib.module.add_productivity_limitations(
{
  "bob-seedling",
  "bob-fertiliser",
  "bob-basic-greenhouse-cycle",
  "bob-advanced-greenhouse-cycle"
}
)


