data:extend(
{
  {
    type = "recipe-category",
    name = "bob-greenhouse"
  },

  {
    type = "item-subgroup",
    name = "bob-greenhouse",
    group = "production",
    order = "e-f"
  },

  {
    type = "item-subgroup",
    name = "bob-greenhouse-items",
    group = "intermediate-products",
    order = "e-f"
  },
}
)

