# Loss Prevention
Manipulates biter evolution to prevent them from getting too far ahead of you, leading to potentially unrecoverable factories and saves.
-----------------
Primary Features:
Biter evolution now has several values which it cannot exceed until you have achieved a corresponding landmark progression.