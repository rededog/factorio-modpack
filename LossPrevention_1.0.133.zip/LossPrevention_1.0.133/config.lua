Config = {}

--Config.spacePlasma = settings.startup["space-plasma"].value--false