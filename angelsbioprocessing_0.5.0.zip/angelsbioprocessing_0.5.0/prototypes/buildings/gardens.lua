data:extend(
{
  {
    type = "item",
    name = "temperate-garden",
    icon = "__angelsbioprocessing__/graphics/icons/temperate-garden.png",
	icon_size = 32,
    flags = {"goes-to-main-inventory"},
    subgroup = "farming-gardens",
    order = "a",
    stack_size = 200
  },  
  {
    type = "tree",
    name = "temperate-garden",
    icon = "__angelsbioprocessing__/graphics/icons/temperate-garden.png",
	icon_size = 32,
    flags = {"placeable-neutral", "placeable-off-grid", "breaths-air"},
    minable =
    {
      mining_particle = "wooden-particle",
      mining_time = 1,
      result = "temperate-garden",
      count = 1
    },
    emissions_per_tick = -0.0001,
    max_health = 20,
    collision_box = {{-1.1, -1.1}, {1.1, 1.1}},
    selection_box = {{-1.3, -1.3}, {1.3, 1.3}},
    subgroup = "trees",
    order = "a[tree]-b[dead-tree]",
    vehicle_impact_sound =  { filename = "__base__/sound/car-wood-impact.ogg", volume = 1.0 },
    -- autoplace =
    -- {
      -- order = "b",
      -- max_probability = 0.05,
      -- peaks =
      -- {
        -- {
          -- influence = 0.0002
        -- },
        -- {
          -- influence = 0.002;
          -- min_influence = 0,
          -- elevation_optimal = 45000,
          -- elevation_range = 37000,
          -- elevation_max_range = 45000,
        -- }
      -- },
	  -- tile_restriction = {"grass-1", "grass-2", "grass-3", "grass-4", "dry-dirt"}
    -- },
	-- autoplace =
		-- {
		-- control = "trees",
		-- max_probability = 1e-2 * 0.3,
		-- sharpness = 0.6,
		-- order = "a[tree]-b[forest]",
		-- random_probability_penalty = 1e-2 * 0.5,
		-- peaks = {
		  -- {
			-- influence = -0.8,	--0.8
			-- richness_influence = 0,
		  -- },
		  -- {
			-- influence = 1,	--1
			-- richness_influence = 0,
			-- noise_layer = "trees",
			-- noise_persistence = 0.5,
			-- noise_octaves_difference = -1.5
		  -- },
		  -- {
			-- influence = 1,
			-- richness_influence = 0,
		  -- },
		  -- starting_area_clearing_peak = {
			  -- influence = -0.25,
			  -- richness_influence = 0,
			  -- distance_optimal = 0,
			  -- distance_range = 128 - 64,
			  -- distance_max_range = 128 + 64,
			  -- distance_top_property_limit = 128,
			-- },		  
		-- },
		-- tile_restriction = {"grass-1", "grass-2", "grass-3", "grass-4", "dry-dirt"},
	-- },
    autoplace =
    {
      order = "za",
      max_probability = 0.05,
      peaks =
      {
        {
          influence = 0.0002
        },
        {
          influence = 0.002;
          min_influence = 0,
          elevation_optimal = 45000,
          elevation_range = 37000,
          elevation_max_range = 45000,
        }
      },
	  tile_restriction = {"grass-1", "grass-2", "grass-3", "grass-4", "dry-dirt"},
    },
    pictures =
	{
      {
        filename = "__angelsbioprocessing__/graphics/entity/gardens/temperate-garden-1.png",
        width = 128,
        height = 128,
		scale = 0.75,
        shift = {0, 0}
      },
      {
        filename = "__angelsbioprocessing__/graphics/entity/gardens/temperate-garden-2.png",
        width = 128,
        height = 128,
		scale = 0.75,
        shift = {0, 0}
      },
      {
        filename = "__angelsbioprocessing__/graphics/entity/gardens/temperate-garden-3.png",
        width = 128,
        height = 128,
		scale = 0.75,
        shift = {0, 0}
      },
      {
        filename = "__angelsbioprocessing__/graphics/entity/gardens/temperate-garden-4.png",
        width = 128,
        height = 128,
		scale = 0.75,
        shift = {0, 0}
      },
      {
        filename = "__angelsbioprocessing__/graphics/entity/gardens/temperate-garden-5.png",
        width = 128,
        height = 128,
		scale = 0.75,
        shift = {0, 0}
      },
	}
  },
  {
    type = "item",
    name = "desert-garden",
    icon = "__angelsbioprocessing__/graphics/icons/desert-garden.png",
	icon_size = 32,
    flags = {"goes-to-main-inventory"},
    subgroup = "farming-gardens",
    order = "b",
    stack_size = 200
  },  
  {
    type = "tree",
    name = "desert-garden",
    icon = "__angelsbioprocessing__/graphics/icons/desert-garden.png",
	icon_size = 32,
    flags = {"placeable-neutral", "placeable-off-grid", "breaths-air"},
    minable =
    {
      mining_particle = "wooden-particle",
      mining_time = 1,
      result = "desert-garden",
      count = 1
    },
    emissions_per_tick = -0.0001,
    max_health = 20,
    collision_box = {{-1.1, -1.1}, {1.1, 1.1}},
    selection_box = {{-1.3, -1.3}, {1.3, 1.3}},
    subgroup = "trees",
    order = "a[tree]-b[dead-tree]",
    vehicle_impact_sound =  { filename = "__base__/sound/car-wood-impact.ogg", volume = 1.0 },
    -- autoplace =
    -- {
      -- order = "b",
      -- max_probability = 0.05,
      -- peaks =
      -- {
        -- {
          -- influence = 0.0002
        -- },
        -- {
          -- influence = 0.002;
          -- min_influence = 0,
          -- elevation_optimal = 45000,
          -- elevation_range = 37000,
          -- elevation_max_range = 45000,
        -- }
      -- },
	  -- tile_restriction = {"red-desert-0", "red-desert-1", "red-desert-2", "red-desert-3", "sand-1", "sand-2", "sand-3"}
    -- },
	-- autoplace =
		-- {
		-- control = "trees",
		-- max_probability = 1e-2 * 0.2,
		-- sharpness = 0.6,
		-- order = "a[tree]-b[forest]",
		-- random_probability_penalty = 1e-2 * 0.5,
		-- peaks = {
		  -- {
			-- influence = -0.8,	--0.8
			-- richness_influence = 0,
		  -- },
		  -- {
			-- influence = 1,	--1
			-- richness_influence = 0,
			-- noise_layer = "trees",
			-- noise_persistence = 0.5,
			-- noise_octaves_difference = -1.5
		  -- },
		  -- {
			-- influence = 1,
			-- richness_influence = 0,
		  -- },
		  -- starting_area_clearing_peak = {
			  -- influence = -0.25,
			  -- richness_influence = 0,
			  -- distance_optimal = 0,
			  -- distance_range = 128 - 64,
			  -- distance_max_range = 128 + 64,
			  -- distance_top_property_limit = 128,
			-- },	  
		-- },
		-- tile_restriction = {"red-desert-0", "red-desert-1", "red-desert-2", "red-desert-3", "sand-1", "sand-2", "sand-3"},
	-- },
    autoplace =
    {
      order = "zb",
      max_probability = 0.05,
      peaks =
      {
        {
          influence = 0.0002
        },
        {
          influence = 0.002;
          min_influence = 0,
          elevation_optimal = 45000,
          elevation_range = 37000,
          elevation_max_range = 45000,
        }
      },
	  tile_restriction = {"red-desert-0", "red-desert-1", "red-desert-2", "red-desert-3", "sand-1", "sand-2", "sand-3"},
    },
    pictures =
	{
      {
        filename = "__angelsbioprocessing__/graphics/entity/gardens/desert-garden-1.png",
        width = 128,
        height = 128,
		scale = 0.75,
        shift = {0, 0}
      },
      {
        filename = "__angelsbioprocessing__/graphics/entity/gardens/desert-garden-2.png",
        width = 128,
        height = 128,
		scale = 0.75,
        shift = {0, 0}
      },
      {
        filename = "__angelsbioprocessing__/graphics/entity/gardens/desert-garden-3.png",
        width = 128,
        height = 128,
		scale = 0.75,
        shift = {0, 0}
      },
      {
        filename = "__angelsbioprocessing__/graphics/entity/gardens/desert-garden-4.png",
        width = 128,
        height = 128,
		scale = 0.75,
        shift = {0, 0}
      },
	}
  },
  {
    type = "item",
    name = "swamp-garden",
    icon = "__angelsbioprocessing__/graphics/icons/swamp-garden.png",
	icon_size = 32,
    flags = {"goes-to-main-inventory"},
    subgroup = "farming-gardens",
    order = "c",
    stack_size = 200
  },  
  {
    type = "tree",
    name = "swamp-garden",
    icon = "__angelsbioprocessing__/graphics/icons/swamp-garden.png",
	icon_size = 32,
    flags = {"placeable-neutral", "placeable-off-grid", "breaths-air"},
    minable =
    {
      mining_particle = "wooden-particle",
      mining_time = 1,
      result = "swamp-garden",
      count = 1
    },
    emissions_per_tick = -0.0001,
    max_health = 20,
    collision_box = {{-1.1, -1.1}, {1.1, 1.1}},
    selection_box = {{-1.3, -1.3}, {1.3, 1.3}},
    subgroup = "trees",
    order = "a[tree]-b[dead-tree]",
    vehicle_impact_sound =  { filename = "__base__/sound/car-wood-impact.ogg", volume = 1.0 },
    -- autoplace =
    -- {
      -- order = "b",
      -- max_probability = 0.05,
      -- peaks =
      -- {
        -- {
          -- influence = 0.0002
        -- },
        -- {
          -- influence = 0.002;
          -- min_influence = 0,
          -- elevation_optimal = 45000,
          -- elevation_range = 37000,
          -- elevation_max_range = 45000,
        -- }
      -- },
	  -- tile_restriction = {"dirt-1", "dirt-2", "dirt-3", "dirt-4", "dirt-5", "dirt-6", "dirt-7"}
    -- },
	-- autoplace =
		-- {
		-- control = "trees",
		-- max_probability = 1e-2 * 0.2,
		-- sharpness = 0.6,
		-- order = "a[tree]-b[forest]",
		-- random_probability_penalty = 1e-2 * 0.5,
		-- peaks = {
		  -- {
			-- influence = -0.8,	--0.8
			-- richness_influence = 0,
		  -- },
		  -- {
			-- influence = 1,	--1
			-- richness_influence = 0,
			-- noise_layer = "trees",
			-- noise_persistence = 0.5,
			-- noise_octaves_difference = -1.5
		  -- },
		  -- {
			-- influence = 1,
			-- richness_influence = 0,
		  -- },
		  -- starting_area_clearing_peak = {
			  -- influence = -0.25,
			  -- richness_influence = 0,
			  -- distance_optimal = 0,
			  -- distance_range = 128 - 64,
			  -- distance_max_range = 128 + 64,
			  -- distance_top_property_limit = 128,
			-- },
		-- },
		-- tile_restriction = {"dirt-1", "dirt-2", "dirt-3", "dirt-4", "dirt-5", "dirt-6", "dirt-7"},
	-- },
    autoplace =
    {
      order = "zc",
      max_probability = 0.05,
      peaks =
      {
        {
          influence = 0.0002
        },
        {
          influence = 0.002;
          min_influence = 0,
          elevation_optimal = 45000,
          elevation_range = 37000,
          elevation_max_range = 45000,
        }
      },
	  tile_restriction = {"dirt-1", "dirt-2", "dirt-3", "dirt-4", "dirt-5", "dirt-6", "dirt-7"},
    },
    pictures =
	{
      {
        filename = "__angelsbioprocessing__/graphics/entity/gardens/swamp-garden-1.png",
        width = 128,
        height = 128,
		scale = 0.75,
        shift = {0, 0}
      },
      {
        filename = "__angelsbioprocessing__/graphics/entity/gardens/swamp-garden-2.png",
        width = 128,
        height = 128,
		scale = 0.75,
        shift = {0, 0}
      },
      {
        filename = "__angelsbioprocessing__/graphics/entity/gardens/swamp-garden-3.png",
        width = 128,
        height = 128,
		scale = 0.75,
        shift = {0, 0}
      },
      -- {
        -- filename = "__angelsbioprocessing__/graphics/entity/gardens/water-garden-4.png",
        -- width = 128,
        -- height = 128,
		-- scale = 0.75,
        -- shift = {0, 0}
      -- },
      -- {
        -- filename = "__angelsbioprocessing__/graphics/entity/gardens/water-garden-5.png",
        -- width = 128,
        -- height = 128,
		-- scale = 0.75,
        -- shift = {0, 0}
      -- },
	}
  },
})
