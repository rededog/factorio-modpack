local OV = angelsmods.functions.OV
--PREPARATION
	OV.remove_output("algae-brown-burning", "angels-void")

--REFINING
if angelsmods.refining then
	--MOVE UNLOCKS
	OV.add_unlock("bio-processing-green", "water-mineralized")
	OV.remove_unlock("water-treatment", "water-mineralized")
end

--SMELTING
if not angelsmods.smelting then
	OV.disable_recipe("algae-brown-burning-wash")
end

--UPDATE BUILDING RECIPES
require("prototypes.recipes.bio-processing-entity-angels")

--CONDITIONAL
if angelsmods.industries then
	OV.modify_output("algae-brown-burning", {"solid-lithium", 1})
else
   if bobmods and bobmods.plates then
      OV.patch_recipes({
         { name = "algae-brown-burning", results = {{"lithium-chloride", 1}} },
         { name = "circuit-wood-fiber-board", results = {{"wooden-board", "circuit-wood-fiber-board"}} },
		 { name = "temperate-upgrade", ingredients = {{"!!"}, {name="token-bio", 5}, {"electronic-circuit", 2}, {"steel-plate", 2}, {"clay-brick", 2}, {"steel-pipe", 2}, } },
		 { name = "desert-upgrade", ingredients = {{"!!"}, {name="token-bio", 5}, {"electronic-circuit", 2}, {"steel-plate", 2}, {"clay-brick", 2}, {"steel-pipe", 2}, } },
		 { name = "swamp-upgrade", ingredients = {{"!!"}, {name="token-bio", 5}, {"electronic-circuit", 2}, {"steel-plate", 2}, {"clay-brick", 2}, {"steel-pipe", 2}, } },
      })
   else
      OV.modify_input("substrate-dish", {"paste-copper", "paste-silver"})
      OV.disable_recipe("algae-brown-burning")
      OV.disable_recipe({"paste-cobalt", "paste-gold", "paste-silver", "paste-titanium", "paste-tungsten", "paste-zinc"})
      OV.disable_recipe({"alien-pre-artifact-yellow", "alien-pre-artifact-blue", "alien-pre-artifact-green", "alien-pre-artifact-purple", "alien-pre-artifact-orange", "alien-pre-artifact-red"})
      OV.disable_recipe({"small-alien-artifact-red", "small-alien-artifact-yellow", "small-alien-artifact-orange", "small-alien-artifact-blue", "small-alien-artifact-purple", "small-alien-artifact-green"})
      OV.disable_recipe({"alien-artifact-red", "alien-artifact-yellow", "alien-artifact-orange", "alien-artifact-blue", "alien-artifact-purple", "alien-artifact-green"})
	end
end

if data.raw.tile["sand-orange-dark"] then
	data.raw.tree["temperate-garden"].autoplace.tile_restriction = {"grass", "grass-medium", "grass-red", "grass-orange", "grass-yellow", "grass-yellow-fade", "grass-purple-fade", "grass-purple"}
	data.raw.tree["desert-garden"].autoplace.tile_restriction = {"sand-red-dark", "sand-orange-dark", "sand-gold-dark", "sand-dark", "sand-dull-dark", "sand-grey-dark", "sand-red", "sand-orange", "sand-gold", "sand", "sand-dull", "sand-grey"}
	data.raw.tree["temperate-garden"].autoplace.tile_restriction = {"dirt-red", "dirt-brown", "dirt-tan-dark", "dirt-dark", "dirt-dull-dark", "dirt-grey-dark", "dirt-tan", "dirt", "dirt-dull", "dirt-grey"}
end

--ADDED RECIPES FOR BOBS ARTIFACTS
if bobmods.enemies and data.raw.item["small-alien-artifact-blue"] then
	require("prototypes.bio-processing-override-bob")
end