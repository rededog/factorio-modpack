data:extend(
{
  {
    type = "recipe",
    name = "stone-waterwell",
	energy_required = 10,
    ingredients =
    {
	  {"iron-stick", 4},
	  {"stone-brick", 8},
	  {"stone", 40},
	  {"pipe-to-ground", 1},
	  {"offshore-pump", 1}
    },
	result_count = 1,
    result = "stone-waterwell"
  }
})